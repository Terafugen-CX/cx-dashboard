// 취합 로직 (화면/네트워크와 무관한 순수 함수) — 브라우저와 Node 양쪽에서 동작
(function (root) {
  const BRANDS = [
    { name: '테라퓨젠', host: 'terafugenbio' },
    { name: '프로즌랩', host: 'frozenlab' },
    { name: '메디그로우', host: 'medigrow' },
    { name: '덴티플라', host: 'dentipla' },
    { name: '셀로핏', host: 'cellofit' },
    { name: '파미코젠', host: 'pamicogen' },
  ];

  // 시트 제품 드롭다운에 있는 이름. 앞에 있는 것이 먼저 일치한다.
  const PRODUCTS = [
    ['조인트본', '조인트본'], ['루테아틴', '루테아틴'], ['헬리코컷', '헬리코컷'], ['콜레스컷', '콜레스컷'],
    ['알래스카', '알래스카'], ['실톡스 크림', '실톡스 크림'], ['실톡스 앰플', '실톡스 앰플'],
    ['콜라겐', '콜라겐부스터'], ['화이토넥스', '화이토넥스'], ['구강케어', '구강케어 정'], ['치약', '치약'],
    ['아나모나', '아나모나'], ['스피모나', '스피모나'], ['플로우턴', '플로우턴'], ['코티프로', '코티프로'],
    ['알코프로', '알코프로'],
  ];

  const mapProducts = text => {
    const out = [];
    for (const [k, v] of PRODUCTS) if (text.includes(k) && !out.includes(v)) out.push(v);
    return out;
  };

  // 상품명을 먼저 보고, 제품명이 없으면 옵션까지 본다 (사은품 문구는 호출 전에 걸러낸다)
  const productFromText = full => {
    const clean = s => s.replace(/블랙프라이데이/g, '');
    const title = full.replace(/^내역\s*/, '').split('[필수]')[0].split('필수 선택')[0].split('★')[0];
    const byTitle = mapProducts(clean(title));
    if (byTitle.length) return byTitle[0];
    const byAll = mapProducts(clean(full));
    return byAll[0] || '';
  };

  const brandFromHost = host => {
    const h = String(host || '').toLowerCase();
    const b = BRANDS.find(x => h.startsWith(x.host + '.') || h.includes(x.host + '.cafe24'));
    return b ? b.name : '';
  };

  const pad = n => String(n).padStart(2, '0');
  const ymd = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

  // 전주 금요일 ~ 금주 목요일: 가장 가까운 지난(또는 오늘) 목요일이 끝, 그 6일 전이 시작
  const defaultPeriod = (today = new Date()) => {
    const d = new Date(today.getFullYear(), today.getMonth(), today.getDate());
    const back = (d.getDay() - 4 + 7) % 7; // 목요일=4
    const end = new Date(d); end.setDate(d.getDate() - back);
    const start = new Date(end); start.setDate(end.getDate() - 6);
    return { start: ymd(start), end: ymd(end) };
  };

  // 주차는 그 달의 N번째 목요일로 끝나는 7일(금~목). 예) 2026-11 → 1주차 10/30~11/5, 4주차 11/20~11/26
  const thursdaysOf = (year, month0) => {
    const out = []; const d = new Date(year, month0, 1);
    while (d.getMonth() === month0) { if (d.getDay() === 4) out.push(new Date(d)); d.setDate(d.getDate() + 1); }
    return out;
  };
  const weekRange = thu => {
    const s = new Date(thu); s.setDate(thu.getDate() - 6);
    return { start: ymd(s), end: ymd(thu) };
  };
  const weekLabel = (year, month0, n) => `${String(year).slice(2)}-${pad(month0 + 1)}(${n}주차)`;
  // 오늘 기준 가장 최근에 끝난(또는 오늘 끝나는) 주차
  const currentWeek = (today = new Date()) => {
    const d = new Date(today.getFullYear(), today.getMonth(), today.getDate());
    const thu = new Date(d); thu.setDate(d.getDate() - ((d.getDay() - 4 + 7) % 7));
    const n = thursdaysOf(thu.getFullYear(), thu.getMonth()).findIndex(t => ymd(t) === ymd(thu)) + 1;
    return { year: thu.getFullYear(), month0: thu.getMonth(), n };
  };

  // 시트(CSV)에서 B열(주문번호)이 채워진 마지막 행 번호 → 다음에 붙여넣을 행 번호
  const nextEmptyRow = csvText => {
    const rows = parseCsv(csvText);
    let last = 1;
    rows.forEach((r, i) => { if (i > 0 && r[1] && r[1].trim()) last = i + 1; });
    return last + 1;
  };

  const decadeFromYear = (year, nowYear = new Date().getFullYear()) => {
    if (!/^\d{4}$/.test(String(year || ''))) return '확인 불가';
    // 올해 - 출생연도 (한국식 +1 아님)
    return Math.floor((nowYear - Number(year)) / 10) * 10 + '대';
  };

  // 관리자 메모(텍스트) → 환불완료 날짜, 취소접수 사유
  const parseMemo = text => {
    const t = String(text || '').replace(/\s+/g, ' ');
    const rf = /(\d{4}-\d\d-\d\d) \d\d:\d\d:\d\d \(시스템\) - \[환불완료\]/.exec(t);
    const rs = /\[취소접수[^\]]*\][^\[]*?(?=\d{4}-\d\d-\d\d|\[환불|메모 내용 등록)/.exec(t);
    return {
      refundDate: rf ? rf[1] : '',
      reason: rs ? rs[0].replace(/^\[취소접수 - ([^\]]*)\]\s*/, '[$1] ').trim() : '',
    };
  };

  // 주문상세(텍스트) → 상품구매금액 / 결제예정금액 / 총 실결제금액
  const parseAmounts = text => {
    const t = String(text || '').replace(/\s+/g, ' ');
    const m = /상품구매금액\s*([\d,]+)\s*결제예정금액\s*([\d,]+)\s*총 실결제금액\s*([\d,]+)/.exec(t);
    if (!m) return null;
    const n = s => Number(s.replace(/,/g, ''));
    return { buy: n(m[1]), due: n(m[2]), total: n(m[3]) };
  };

  // 0원이면 상품구매금액
  const amountForSheet = a => (a ? (a.total !== 0 ? a.total : a.buy) : '');

  // 주문상세(텍스트) → 사은품이 아닌 상품 문구 목록
  const parseDetailItems = text => {
    const t = String(text || '').replace(/\s+/g, ' ');
    const i = t.indexOf('상품명/옵션');
    if (i < 0) return [];
    const j = t.indexOf('배송상품추가', i);
    return t.slice(i, j < 0 ? undefined : j)
      .split('상품 상세보기 쇼핑몰화면 진열보기').slice(1)
      .map(s => s.replace(/\s\d+ [\d,]+ [\d,]+ \d+ [\d,]+ \(기본\).*$/, '').trim())
      .filter(s => s && !s.includes('사은품'));
  };

  // 회원 주문정보 표의 한 줄 텍스트 → {dt,id,amt}
  const parseOrderLine = text => {
    const m = /(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d)\s+(\d{8}-\d{7})\s+([\d,]+)/.exec(String(text || '').replace(/\s+/g, ' '));
    return m ? { dt: m[1], id: m[2], amt: m[3] } : null;
  };

  // 취소된 주문 이후 주문(결제금액 0 제외) 중 가장 최근 것
  const latestReorder = (orders, cancelledId) => {
    const uniq = [...new Map(orders.map(o => [o.id, o])).values()];
    const me = uniq.find(o => o.id === cancelledId);
    if (!me) return null;
    const later = uniq.filter(o => o.dt > me.dt && o.amt !== '0').sort((a, b) => b.dt.localeCompare(a.dt));
    return later[0] || null;
  };

  // 같은 재주문번호를 여러 취소 건이 가리키면, 취소 시각이 가장 늦은 한 건에만 남긴다
  const dedupeSharedReorders = rows => {
    const groups = {};
    rows.forEach((r, i) => { if (r.L) (groups[r.brand + '|' + r.L] = groups[r.brand + '|' + r.L] || []).push(i); });
    Object.values(groups).forEach(idx => {
      if (idx.length < 2) return;
      idx.sort((a, b) => String(rows[b].acceptTime).localeCompare(String(rows[a].acceptTime)));
      idx.slice(1).forEach(i => { rows[i].L = ''; rows[i].M = ''; rows[i].N = ''; });
    });
    return rows;
  };

  // 날짜 → 취소완료 먼저 → 주문번호
  const sortRows = rows => rows.slice().sort((a, b) =>
    a.A.localeCompare(b.A) || (a.prepaid - b.prepaid) || a.B.localeCompare(b.B));

  const fmtMoney = n => (n === '' || n == null ? '' : Number(n).toLocaleString('en-US'));

  // 붙여넣기용 표. A열(취소일)은 날짜가 바뀌는 첫 행에만 적는다.
  const toTsv = rows => {
    let prev = '';
    return rows.map(r => {
      const a = r.A !== prev ? r.A : '';
      prev = r.A;
      return [a, r.B, r.C, '취소', r.brand, '자사몰', r.G, r.H, r.I, r.J, r.K, r.L, r.M, r.N === '' ? '' : fmtMoney(r.N)].join('\t');
    }).join('\n');
  };

  // CSV(시트 내보내기) → "브랜드|주문번호" 집합. B열=주문번호, E열=브랜드
  const parseCsv = text => {
    const rows = []; let row = [], cell = '', q = false;
    for (let i = 0; i < text.length; i++) {
      const c = text[i];
      if (q) {
        if (c === '"') { if (text[i + 1] === '"') { cell += '"'; i++; } else q = false; } else cell += c;
      } else if (c === '"') q = true;
      else if (c === ',') { row.push(cell); cell = ''; }
      else if (c === '\n') { row.push(cell); rows.push(row); row = []; cell = ''; }
      else if (c !== '\r') cell += c;
    }
    if (cell || row.length) { row.push(cell); rows.push(row); }
    return rows;
  };
  const existingKeys = csvText => new Set(parseCsv(csvText).slice(1)
    .filter(r => r[1]).map(r => (r[4] || '').trim() + '|' + r[1].trim()));

  // "26-11-14", "2026-11-14", "2026-11-14 12:00" → "2026-11-14" (읽을 수 없으면 '')
  const normDate = s => {
    const m = /(\d{2,4})\D(\d{1,2})\D(\d{1,2})/.exec(String(s || ''));
    if (!m) return '';
    const y = m[1].length === 2 ? 2000 + Number(m[1]) : Number(m[1]);
    return `${y}-${pad(Number(m[2]))}-${pad(Number(m[3]))}`;
  };

  // 시트(CSV 행 배열, 0번째가 헤더)에서 날짜 묶음을 찾는다.
  // A열에 날짜가 있는 행이 묶음의 시작이고, 다음 날짜가 나오기 전까지(B열이 채워진 행)가 그 묶음이다.
  // 반환 행 번호는 시트의 실제 행 번호(1행=헤더).
  const sheetGroups = csvRows => {
    const groups = []; let cur = null, last = 1;
    for (let i = 1; i < csvRows.length; i++) {
      const r = csvRows[i]; const row = i + 1;
      const d = normDate(r[0]);
      const hasB = !!(r[1] && r[1].trim());
      if (d) { cur = { date: d, start: row, end: row }; groups.push(cur); }
      if (hasB) { last = row; if (cur) cur.end = row; }
    }
    return { groups, last };
  };

  // 날짜별 새 건 수 → 삽입 계획. 날짜가 늦은 것부터 처리해야 앞쪽 행 번호가 밀리지 않는다.
  // after: 이 행 아래에 넣는다 / insert: 행을 삽입해야 하는지(끝에 붙이는 경우는 불필요) / newGroup: 새 날짜 묶음인지
  const planInsertions = (groups, lastRow, dateCounts) => {
    const ops = []; let last = lastRow;
    dateCounts.slice().sort((a, b) => b.date.localeCompare(a.date)).forEach(d => {
      const same = groups.find(g => g.date === d.date);
      let after, newGroup;
      if (same) { after = same.end; newGroup = false; }
      else {
        const prev = groups.filter(g => g.date < d.date).sort((a, b) => b.date.localeCompare(a.date))[0];
        after = prev ? prev.end : 1; newGroup = true;
      }
      ops.push({ date: d.date, count: d.count, after, newGroup, insert: after < last });
      last += d.count;
    });
    return ops;
  };

  // 한 날짜 묶음의 붙여넣기용 표. 기존 묶음에 들어가면 A열은 비우고, 새 묶음이면 첫 행에만 날짜를 적는다.
  const toTsvBucket = (rows, newGroup) => rows.map((r, i) =>
    [newGroup && i === 0 ? r.A : '', r.B, r.C, '취소', r.brand, '자사몰', r.G, r.H, r.I, r.J, r.K, r.L, r.M, r.N === '' ? '' : fmtMoney(r.N)].join('\t')).join('\n');

  const api = {
    normDate, sheetGroups, planInsertions, toTsvBucket,
    BRANDS, PRODUCTS, mapProducts, productFromText, brandFromHost, defaultPeriod, decadeFromYear,
    thursdaysOf, weekRange, weekLabel, currentWeek, nextEmptyRow,
    parseMemo, parseAmounts, amountForSheet, parseDetailItems, parseOrderLine, latestReorder,
    dedupeSharedReorders, sortRows, toTsv, parseCsv, existingKeys, ymd,
  };
  root.TB = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
