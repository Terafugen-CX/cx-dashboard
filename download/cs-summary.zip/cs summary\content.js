(() => {
  if (window.top !== window) return;
  if (window.__tbLoaded) return;
  window.__tbLoaded = true;

  const T = globalThis.TB;
  const IS_SHEET = location.hostname === 'docs.google.com';
  const BRAND = IS_SHEET ? '' : T.brandFromHost(location.hostname);
  const CANCEL_PATH = '/admin/php/shop1/s/order_cancel.php';
  const JOB_KEY = 'tb_job';

  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const LOGIN_URL = 'https://eclogin.cafe24.com/Shop/?url=Init&login_mode=2';
  // 로그아웃 직후에는 다음 브랜드 로그인을 위해 로그인 화면으로 돌아간다
  if (!IS_SHEET && /\/log_out\.php$/.test(location.pathname)) { setTimeout(() => location.replace(LOGIN_URL), 1200); return; }
  const store = {
    get: k => new Promise(r => chrome.storage.local.get(k, v => r(v[k]))),
    set: (k, v) => new Promise(r => chrome.storage.local.set({ [k]: v }, r)),
  };

  // ───────────── 화면 ─────────────
  const host = document.createElement('div');
  host.id = 'tb-host';
  host.style.cssText = 'all: initial;';
  document.documentElement.appendChild(host);
  const root = host.attachShadow({ mode: 'open' });

  const style = document.createElement('style');
  style.textContent = `
    * { box-sizing: border-box; margin: 0; padding: 0; }
    #toggle {
      position: fixed; bottom: 90px; right: 21.6px;
      width: 40px; height: 40px; padding: 0; border: none; background: none;
      cursor: grab; z-index: 2147483646; transition: transform .18s, opacity .22s;
      touch-action: none; user-select: none;
    }
    #toggle:hover { transform: scale(1.1); }
    #toggle.dragging { cursor: grabbing; transition: none; }
    #toggle svg { display: block; width: 100%; height: 100%; pointer-events: none;
      filter: drop-shadow(0 3px 5px rgba(11,92,171,.45)) drop-shadow(0 7px 12px rgba(11,92,171,.25)); }
    #panel {
      position: fixed; right: 18px; bottom: 86.4px;
      width: 360px; height: 600px; max-height: 92vh;
      background: #fff; border-radius: 16.2px; overflow: hidden;
      box-shadow: 0 12.6px 43.2px rgba(15,40,80,.2), 0 2.7px 9px rgba(15,40,80,.1);
      z-index: 2147483647; display: flex; flex-direction: column;
      font-family: 'Malgun Gothic','맑은 고딕',sans-serif; font-size: 11.7px; color: #2d3748;
      opacity: 0; transform: translateY(12.6px); pointer-events: none;
      transition: opacity .22s ease, transform .22s ease;
    }
    #panel.open { opacity: 1; transform: translateY(0); pointer-events: auto; }
    .hdr { background: linear-gradient(135deg,#1a8cf0,#0b5cab); color: #fff; padding: 9px 14.4px 11.7px;
      display: flex; justify-content: space-between; align-items: center; flex-shrink: 0; cursor: move; user-select: none; }
    .hdr .t-main { display: block; font-weight: 800; font-size: 13.1px; line-height: 1.15; }
    .hdr-btns { display: flex; gap: 2px; align-items: center; }
    .hdr-btns button { background: none; border: none; color: #fff; font-size: 13.5px; cursor: pointer;
      padding: 2.7px 7.2px; border-radius: 6.3px; line-height: 1; display: flex; align-items: center; justify-content: center; }
    .hdr-btns button:hover { background: rgba(255,255,255,.22); }
    #gear.on { background: rgba(255,255,255,.25); box-shadow: 0 0 0 2px rgba(255,255,255,.65), 0 0 9px rgba(255,255,255,.55); }

    .body { flex: 1; overflow-y: auto; padding: 12.6px; background: #f7fafd; display: flex; flex-direction: column; gap: 9px; }
    .card { background: #fff; border: 1.5px solid #e2e8f0; border-radius: 10.8px; padding: 10.8px 12.6px; }
    .card-title { font-size: 11.7px; font-weight: 800; color: #1e293b; margin-bottom: 7.2px; }
    .row { display: flex; align-items: center; gap: 5.4px; }
    .row + .row { margin-top: 5.4px; }
    input[type=date] { flex: 1; border: 1.5px solid #e2e8f0; border-radius: 9px; padding: 7.2px 8.1px;
      font-size: 10.8px; font-family: inherit; outline: none; min-width: 0; }
    input[type=date]:focus { border-color: #1a8cf0; }
    input[type=month], input[type=text] { flex: 1; border: 1.5px solid #e2e8f0; border-radius: 9px; padding: 7.2px 8.1px;
      font-size: 10.8px; font-family: inherit; outline: none; min-width: 0; }
    input[type=month]:focus, input[type=text]:focus { border-color: #1a8cf0; }
    .btn-sec.on { background: #f4f9ff; border-color: #1a8cf0; color: #0b5cab; }
    .sep { color: #94a3b8; font-size: 11px; }
    .btn-pri { background: linear-gradient(135deg,#1a8cf0,#0b5cab); color: #fff; border: none; border-radius: 9px;
      padding: 8.1px 13.5px; font-size: 10.8px; font-weight: 800; cursor: pointer; font-family: inherit; flex: 1; }
    .btn-pri:hover { filter: brightness(1.07); }
    .btn-pri:disabled { background: #cbd5e1; cursor: not-allowed; filter: none; }
    .btn-sec { background: #fff; color: #475569; border: 1.5px solid #e2e8f0; border-radius: 9px;
      padding: 7.2px 12.6px; font-size: 10.3px; font-weight: 700; cursor: pointer; font-family: inherit; }
    .btn-sec:hover { border-color: #cbd5e1; background: #f8fafc; }
    .brand { display: flex; align-items: center; justify-content: space-between; padding: 5.4px 0; border-bottom: 1px solid #eef2f7; }
    .brand:last-child { border-bottom: none; }
    .brand .b-right { display: flex; align-items: center; gap: 6px; }
    .brand .b-go { padding: 3px 10px; font-size: 10px; border-radius: 7px; color: #0b5cab; border-color: #bfdcf8; background: #f4f9ff; }
    .brand .b-go:hover { background: #e6f1ff; border-color: #1a8cf0; }
    .brand .b-name { font-weight: 700; color: #1e293b; }
    .brand .b-name.me { color: #0b5cab; }
    .brand .b-stat { font-size: 10px; color: #94a3b8; }
    .brand .b-stat.ok { color: #0b5cab; font-weight: 700; }
    .note { font-size: 9.9px; color: #94a3b8; line-height: 1.6; }
    #log { font-family: Consolas, monospace; font-size: 9.9px; color: #475569; white-space: pre-wrap; line-height: 1.55;
      max-height: 150px; overflow-y: auto; }

    .set { position: absolute; top: 52.2px; left: 0; right: 0; bottom: 0; background: #fff; display: none; flex-direction: column; z-index: 5; }
    .set.open { display: flex; }
    .set-nav { display: flex; align-items: center; justify-content: space-between; padding: 9.9px 14.4px; border-bottom: 1px solid #eef2f7; flex-shrink: 0; }
    .set-nav .n-title { font-weight: 800; font-size: 11.7px; color: #0b5cab; }
    .set-nav button { background: none; border: none; color: #0b5cab; font-size: 12.6px; font-weight: 700; cursor: pointer; font-family: inherit; padding: 2px 3.6px; }
    .set-body { flex: 1; overflow-y: auto; padding: 12.6px 14.4px; }
  `;
  root.appendChild(style);

  const toggle = document.createElement('button');
  toggle.id = 'toggle';
  toggle.innerHTML = `
    <svg viewBox="0 0 64 64" width="100%" height="100%" aria-hidden="true">
      <defs>
        <radialGradient id="tb-sphere" cx="35%" cy="28%" r="80%">
          <stop offset="0" stop-color="#ffffff"/><stop offset=".6" stop-color="#eaf3ff"/><stop offset="1" stop-color="#b4d5fa"/>
        </radialGradient>
        <linearGradient id="tb-blue" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stop-color="#58b0ff"/><stop offset="1" stop-color="#0b5cab"/>
        </linearGradient>
        <radialGradient id="tb-lens" cx="35%" cy="30%" r="75%">
          <stop offset="0" stop-color="#ffffff" stop-opacity=".95"/><stop offset="1" stop-color="#8cc6ff" stop-opacity=".35"/>
        </radialGradient>
      </defs>
      <circle cx="32" cy="32" r="29.5" fill="url(#tb-sphere)" stroke="url(#tb-blue)" stroke-width="3"/>
      <ellipse cx="24" cy="14.5" rx="13" ry="6" fill="#fff" opacity=".75" transform="rotate(-22 24 14.5)"/>
      <line x1="38.7" y1="39.2" x2="48.7" y2="49.2" stroke="#0b3f7a" stroke-opacity=".28" stroke-width="5.5" stroke-linecap="round"/>
      <line x1="37.5" y1="37.5" x2="47.5" y2="47.5" stroke="url(#tb-blue)" stroke-width="5.5" stroke-linecap="round"/>
      <circle cx="29" cy="29" r="11" fill="url(#tb-lens)" stroke="url(#tb-blue)" stroke-width="4.5"/>
      <path d="M22.5 26 A7.5 7.5 0 0 1 28 21.5" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" opacity=".9"/>
    </svg>`;
  root.appendChild(toggle);

  const panel = document.createElement('div');
  panel.id = 'panel';
  panel.innerHTML = `
    <div class="hdr" id="hdr">
      <span class="t-main">cs summary</span>
      <div class="hdr-btns">
        <button id="gear" title="설정">
          <svg viewBox="0 0 24 24" width="16" height="16" fill="#fff" aria-hidden="true">
            <path d="M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58a.49.49 0 0 0 .12-.61l-1.92-3.32a.488.488 0 0 0-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54a.484.484 0 0 0-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96a.488.488 0 0 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58a.49.49 0 0 0-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32a.49.49 0 0 0-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z"/>
          </svg>
        </button>
        <button id="close" title="닫기">✕</button>
      </div>
    </div>
    <div class="body" id="body">
      <div class="card">
        <div class="card-title">기간 (취소접수일 기준)</div>
        <div class="row"><input type="date" id="d-start"><span class="sep">~</span><input type="date" id="d-end"></div>
        <div class="row"><input type="month" id="d-month"></div>
        <div class="row" id="weeks" style="flex-wrap:wrap"></div>
      </div>
      <div class="card">
        <div class="card-title">브랜드 현황</div>
        <div id="brands"></div>
        <div class="row" style="margin-top:7.2px"><button class="btn-sec" id="clear-all">수집 결과 지우기</button></div>
      </div>
      <div class="card" id="act-card"></div>
      <div class="card">
        <div class="card-title">진행 상황</div>
        <div id="log">대기 중</div>
      </div>
    </div>
    <div class="set" id="set">
      <div class="set-nav"><span class="n-title">설정</span><button id="set-close">✕</button></div>
      <div class="set-body" id="set-body"></div>
    </div>
  `;
  root.appendChild(panel);
  // 패널 안에서 치는 글자·붙여넣기가 구글 시트의 단축키 처리로 새지 않게 막는다 (입력칸에 글자가 안 들어가는 문제 방지)
  ['keydown', 'keyup', 'keypress', 'paste', 'copy', 'cut'].forEach(t => panel.addEventListener(t, e => e.stopPropagation()));

  const $ = id => root.getElementById(id);
  const gear = $('gear'), setPane = $('set');
  const logEl = $('log');
  let logLines = [];
  const log = msg => {
    logLines.push(msg);
    if (logLines.length > 60) logLines = logLines.slice(-60);
    logEl.textContent = logLines.join('\n');
    logEl.scrollTop = logEl.scrollHeight;
  };

  const openPanel = open => {
    panel.classList.toggle('open', open);
    if (!open) { setPane.classList.remove('open'); gear.classList.remove('on'); }
  };
  // 아이콘 끌어서 이동 (4px 이상 움직이면 이동, 아니면 클릭으로 패널 열기/닫기)
  let tDrag = null, tMoved = false;
  const clampPos = (x, y) => [
    Math.max(0, Math.min(window.innerWidth - toggle.offsetWidth, x)),
    Math.max(0, Math.min(window.innerHeight - toggle.offsetHeight, y)),
  ];
  const placeToggle = (x, y) => {
    const [cx, cy] = clampPos(x, y);
    Object.assign(toggle.style, { left: cx + 'px', top: cy + 'px', right: 'auto', bottom: 'auto' });
    return [cx, cy];
  };
  toggle.addEventListener('mousedown', e => {
    if (e.button !== 0) return;
    const r = toggle.getBoundingClientRect();
    tDrag = { sx: e.clientX, sy: e.clientY, ox: r.left, oy: r.top };
    tMoved = false;
    e.preventDefault();
  });
  window.addEventListener('mousemove', e => {
    if (!tDrag) return;
    const dx = e.clientX - tDrag.sx, dy = e.clientY - tDrag.sy;
    if (!tMoved && Math.hypot(dx, dy) < 4) return;
    tMoved = true; toggle.classList.add('dragging');
    placeToggle(tDrag.ox + dx, tDrag.oy + dy);
  });
  window.addEventListener('mouseup', () => {
    if (!tDrag) return;
    toggle.classList.remove('dragging');
    if (tMoved) { const r = toggle.getBoundingClientRect(); store.set('tb_toggle_pos', { x: r.left, y: r.top }); }
    tDrag = null;
  });
  toggle.addEventListener('click', () => {
    if (tMoved) { tMoved = false; return; }   // 끌고 놓은 직후의 클릭은 무시
    openPanel(!panel.classList.contains('open'));
  });
  window.addEventListener('resize', () => {
    if (toggle.style.left) { const r = toggle.getBoundingClientRect(); placeToggle(r.left, r.top); }
  });
  store.get('tb_toggle_pos').then(p => { if (p) placeToggle(p.x, p.y); });
  $('close').addEventListener('click', () => openPanel(false));
  gear.addEventListener('click', () => {
    const o = !setPane.classList.contains('open');
    setPane.classList.toggle('open', o); gear.classList.toggle('on', o);
  });
  $('set-close').addEventListener('click', () => { setPane.classList.remove('open'); gear.classList.remove('on'); });

  // 헤더를 잡고 패널 이동
  let drag = null;
  $('hdr').addEventListener('mousedown', e => {
    if (e.target.closest('button')) return;
    const r = panel.getBoundingClientRect();
    drag = { dx: e.clientX - r.left, dy: e.clientY - r.top };
    Object.assign(panel.style, { left: r.left + 'px', top: r.top + 'px', right: 'auto', bottom: 'auto' });
    e.preventDefault();
  });
  window.addEventListener('mousemove', e => {
    if (!drag) return;
    panel.style.left = Math.max(0, Math.min(window.innerWidth - 60, e.clientX - drag.dx)) + 'px';
    panel.style.top = Math.max(0, Math.min(window.innerHeight - 40, e.clientY - drag.dy)) + 'px';
  });
  window.addEventListener('mouseup', () => { drag = null; });

  // ───────────── 기간 ─────────────
  const dStart = $('d-start'), dEnd = $('d-end');
  const dMonth = $('d-month'), weeksEl = $('weeks');
  const monthWeeks = () => {
    const [y, m] = dMonth.value.split('-').map(Number);
    return y && m ? T.thursdaysOf(y, m - 1).map(t => T.weekRange(t)) : [];
  };
  const renderWeeks = () => {
    weeksEl.innerHTML = monthWeeks().map((w, i) =>
      `<button class="btn-sec wk${w.start === dStart.value && w.end === dEnd.value ? ' on' : ''}" data-i="${i}">${i + 1}주차</button>`).join('');
  };
  weeksEl.addEventListener('click', e => {
    const b = e.target.closest('.wk'); if (!b) return;
    const w = monthWeeks()[Number(b.dataset.i)]; if (!w) return;
    dStart.value = w.start; dEnd.value = w.end; savePeriod(); renderWeeks();
  });
  dMonth.addEventListener('change', renderWeeks);
  const loadPeriod = async () => {
    let p = await store.get('tb_period');
    if (!p) {
      const c = T.currentWeek();
      p = T.weekRange(T.thursdaysOf(c.year, c.month0)[c.n - 1]);
    }
    dStart.value = p.start; dEnd.value = p.end;
    dMonth.value = p.end.slice(0, 7);
    renderWeeks();
  };
  const savePeriod = () => store.set('tb_period', { start: dStart.value, end: dEnd.value });
  dStart.addEventListener('change', () => { savePeriod(); renderWeeks(); });
  dEnd.addEventListener('change', () => { savePeriod(); renderWeeks(); });

  // ───────────── 브랜드 현황 ─────────────
  const results = async () => (await store.get('tb_results')) || {};
  const renderBrands = async () => {
    const res = await results();
    $('brands').innerHTML = T.BRANDS.map(b => {
      const r = res[b.name];
      const stat = r ? `${r.rows.length}건 · ${r.start}~${r.end}` : '';
      return `<div class="brand"><span class="b-name${b.name === BRAND ? ' me' : ''}">${esc(b.name)}${b.name === BRAND ? ' (현재 로그인)' : ''}</span>` +
        `<span class="b-right"><span class="b-stat${r ? ' ok' : ''}">${esc(stat)}</span>` +
        `<button class="btn-sec b-go" data-b="${esc(b.name)}">${r ? '재수집' : '수집'}</button></span></div>`;
    }).join('');
  };
  // 브랜드의 "수집"을 누르면 그 브랜드의 카페24 로그인 화면을 열고, 로그인하면 3~5초 뒤 자동으로 수집을 시작한다
  $('brands').addEventListener('click', async e => {
    const b = e.target.closest('.b-go'); if (!b) return;
    const brand = b.dataset.b;
    log(`${brand} 수집 요청…`);   // 눌렀다는 것이 바로 보이게 한다
    try {
      // 확장을 새로고침한 뒤 이 페이지를 새로 고치지 않으면 확장과의 연결이 끊긴다
      if (!chrome.runtime || !chrome.runtime.id) { log('확장이 새로 고쳐져 이 페이지와 연결이 끊겼습니다. 이 페이지를 F5로 새로 고친 뒤 다시 눌러 주세요.'); return; }
      if (!dStart.value || !dEnd.value || dStart.value > dEnd.value) { log('기간을 확인해 주세요.'); return; }
      await savePeriod();
      if (!IS_SHEET && brand === BRAND) { startCollect(); return; }   // 이미 이 브랜드로 로그인된 화면이면 바로 시작
      await store.set('tb_pending', { brand, start: dStart.value, end: dEnd.value, ts: Date.now() });
      chrome.runtime.sendMessage({ type: 'openLogin' }, r => {
        if (chrome.runtime.lastError || !(r && r.ok)) log('카페24 로그인 화면을 열지 못했습니다: ' + ((chrome.runtime.lastError && chrome.runtime.lastError.message) || '응답 없음'));
        else log(`${brand}: 카페24 로그인 화면을 열었습니다. 로그인하면 3~5초 뒤 자동으로 수집을 시작합니다.`);
      });
    } catch (err) {
      log('수집 시작 실패: ' + (err && err.message || err) + ' — 이 페이지를 F5로 새로 고친 뒤 다시 눌러 주세요.');
    }
  });
  $('clear-all').addEventListener('click', async () => {
    await store.set('tb_results', {}); await renderBrands(); log('수집 결과를 지웠습니다.');
  });

  // ───────────── 카페24 수집 ─────────────
  const setVal = (el, v) => {
    const proto = el.tagName === 'SELECT' ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, v);
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  };
  const waitFor = async (fn, ms = 12000) => {
    const t0 = Date.now();
    while (Date.now() - t0 < ms) { const v = fn(); if (v) return v; await sleep(250); }
    return null;
  };
  const getText = async url => {
    const r = await fetch(url, { credentials: 'include' });
    if (!r.ok) throw new Error('HTTP ' + r.status + ' ' + url);
    return r.text();
  };
  const toDoc = html => new DOMParser().parseFromString(html, 'text/html');
  const textOf = html => toDoc(html).body.innerText;

  const listRows = () => [...document.querySelectorAll('table tbody tr')]
    .filter(r => r.cells.length >= 9 && /\d{8}-\d{7}-\d\d/.test(r.innerText));

  const collectOrders = (job) => {
    const orders = new Map(); let skippedStatus = 0;
    const inRange = d => d && d >= job.start && d <= job.end;
    for (const r of listRows()) {
      const c = r.cells;
      const m = /(\d{8}-\d{7})-\d\d/.exec(c[3].innerText);
      const acc = /\(([\d-]+ [\d:]+)\)/.exec(c[2].innerText);
      if (!m || !acc || !inRange(acc[1].slice(0, 10))) continue;
      const st = (c[14] ? c[14].innerText : '').replace(/\s+/g, ' ').trim();
      const prepaid = st.startsWith('입금전취소');
      if (st !== '취소완료' && !prepaid) { skippedStatus++; continue; }
      let o = orders.get(m[1]);
      if (!o) {
        o = {
          id: m[1], acceptTime: acc[1], acc: acc[1].slice(0, 10), prepaid,
          name: c[4].innerText.trim().split(/\s+/)[0],
          uid: (/(\w+@\w)/.exec(c[4].innerText) || [])[1] || '', items: [],
        };
        orders.set(m[1], o);
      }
      o.items.push(c[6].innerText.replace(/\s+/g, ' ').trim());
    }
    return { list: [...orders.values()], skippedStatus };
  };

  const buildRow = async (o, brand) => {
    const base = '';
    const [memoHtml, detHtml, m101, m1] = await Promise.all([
      getText(`${base}/admin/php/s/order_memo.php?order_id=${o.id}&menu_no=76`),
      getText(`${base}/admin/php/s_new/order_detail.php?order_id=${o.id}&menu_no=76`),
      o.uid ? getText(`${base}/admin/php/c/member_admin_d_f.php?mode=101&user_id=${encodeURIComponent(o.uid)}`) : '',
      o.uid ? getText(`${base}/admin/php/c/member_admin_d_f.php?mode=1&user_id=${encodeURIComponent(o.uid)}`) : '',
    ]);
    const memo = T.parseMemo(textOf(memoHtml));
    const amounts = T.parseAmounts(textOf(detHtml));
    const birth = m101 ? (toDoc(m101).querySelector('[name=lunar_calendar1]') || {}).value : '';
    const gift = s => s.includes('사은품');
    const mainItem = o.items.find(s => !gift(s)) || o.items[0] || '';

    const row = {
      brand, prepaid: o.prepaid ? 1 : 0, acceptTime: o.acceptTime,
      A: o.prepaid ? o.acc : (memo.refundDate || o.acc), B: o.id, C: o.acc, G: o.name,
      H: o.uid ? T.decadeFromYear(birth) : '확인 불가',
      I: T.productFromText(mainItem),
      J: o.prepaid ? '입금 전 취소' : (memo.reason || '단순 변심'),
      K: T.amountForSheet(amounts), L: '', M: '', N: '',
    };

    if (m1) {
      const orders = [...toDoc(m1).querySelectorAll('tr')].map(tr => T.parseOrderLine(tr.innerText)).filter(Boolean);
      const re = T.latestReorder(orders, o.id);
      if (re) {
        const reHtml = await getText(`${base}/admin/php/s_new/order_detail.php?order_id=${re.id}&menu_no=76`);
        const items = T.parseDetailItems(textOf(reHtml));
        row.L = re.id;
        row.M = items.length ? T.productFromText(items[0]) : '';
        row.N = Number(re.amt.replace(/,/g, ''));
      }
    }
    return row;
  };

  const runPool = async (items, limit, fn) => {
    const out = new Array(items.length); let i = 0;
    await Promise.all(Array.from({ length: Math.min(limit, items.length) }, async () => {
      while (i < items.length) { const k = i++; out[k] = await fn(items[k], k); }
    }));
    return out;
  };

  let extracting = false;
  const extract = async job => {
    if (extracting) return; extracting = true;
    try {
      const rowsShown = listRows().length;
      const rpp = document.querySelector('select[name=rows]');
      log(`목록 ${rowsShown}건 확인 (페이지당 ${rpp ? rpp.value : '?'}건)`);
      if (rpp && rowsShown >= Number(rpp.value)) log('※ 한 페이지를 가득 채웠습니다. 다음 페이지 건이 빠졌을 수 있습니다.');
      const { list, skippedStatus } = collectOrders(job);
      if (skippedStatus) log(`취소완료·입금전취소가 아닌 ${skippedStatus}행은 제외`);
      log(`${job.brand}: 기간 내 ${list.length}건 상세 수집 중…`);
      let done = 0;
      const rows = await runPool(list, 4, async o => {
        try { const r = await buildRow(o, job.brand); log(`  ${++done}/${list.length} ${o.id}`); return r; }
        catch (e) { log(`  실패 ${o.id}: ${e.message}`); return null; }
      });
      const ok = T.dedupeSharedReorders(rows.filter(Boolean));
      const res = await results();
      res[job.brand] = { rows: ok, start: job.start, end: job.end, at: Date.now() };
      await store.set('tb_results', res);
      sessionStorage.removeItem(JOB_KEY);
      log(`완료: ${job.brand} ${ok.length}건 저장 (실패 ${rows.length - ok.length}건)`);
      await renderBrands();
      refreshActions();
      // 연결된 시트 탭에 기재를 요청한다 — 열려 있는 시트 탭이 알아서 이어받는다
      await store.set('tb_pending_write', Date.now());
      chrome.runtime.sendMessage({ type: 'ensureSheet' }, r => {
        if (r && r.ok) log(r.opened ? '연결된 시트 탭을 열어 기재를 요청했습니다.' : '열려 있는 시트 탭에 기재를 요청했습니다.');
        else log('※ 시트 기재 요청 실패: ' + ((r && r.error) || '응답 없음') + ' (시트를 한 번 열어 두어야 합니다)');
      });
      // 패널에서 누른 자동 수집이면 끝난 뒤 로그아웃해서 다음 브랜드 로그인 화면으로 돌려놓는다
      if (job.auto) { log('수집이 끝나 로그아웃합니다…'); await sleep(2500); location.href = location.origin + '/admin/php/shop1/log_out.php'; }
    } finally { extracting = false; }
  };

  const step = async () => {
    const raw = sessionStorage.getItem(JOB_KEY);
    if (!raw) return;
    const job = JSON.parse(raw);
    if (location.pathname !== CANCEL_PATH) return;
    openPanel(true);
    log(`${job.brand} 취합 이어서 진행 (${job.stage})`);
    const startEl = await waitFor(() => document.querySelector('#startDate'));
    if (!startEl) { log('조회 화면을 찾지 못했습니다. 로그인 상태를 확인해 주세요.'); sessionStorage.removeItem(JOB_KEY); return; }

    if (job.stage === 'init') {
      const rpp = document.querySelector('select[name=rows]');
      if (rpp && rpp.value !== '100') {
        setVal(rpp, '100'); log('페이지당 100건으로 변경');
        await sleep(3500);          // 페이지가 다시 로드되면 이 실행은 끝나고 새로 이어진다
        if (document.querySelector('select[name=rows]').value !== '100') { log('100건 보기 변경 실패'); return; }
      }
      job.stage = 'search'; sessionStorage.setItem(JOB_KEY, JSON.stringify(job));
    }
    if (job.stage === 'search') {
      const sel = document.querySelector('select[name=date_type]');
      if (sel) setVal(sel, 'cancel_date');
      setVal(document.querySelector('#startDate'), job.start);
      setVal(document.querySelector('#endDate'), job.end);
      job.stage = 'extract'; sessionStorage.setItem(JOB_KEY, JSON.stringify(job));
      log(`조회: ${job.start} ~ ${job.end}`);
      const btn = document.querySelector('#search_button');
      if (!btn) { log('검색 버튼을 찾지 못했습니다.'); return; }
      btn.click();
      await sleep(4500);            // 다시 로드되면 이 실행은 끝나고 'extract'로 이어진다
    }
    const cur = JSON.parse(sessionStorage.getItem(JOB_KEY) || 'null');
    if (cur && cur.stage === 'extract') { await waitFor(() => document.querySelector('table tbody tr'), 6000); await extract(cur); }
  };

  const startCollectWith = async (job0) => {
    if (!BRAND) return;
    logLines = [];
    sessionStorage.setItem(JOB_KEY, JSON.stringify({ brand: BRAND, start: job0.start, end: job0.end, auto: !!job0.auto, stage: 'init' }));
    if (location.pathname !== CANCEL_PATH) { log('취소 관리 화면으로 이동합니다…'); location.href = location.origin + CANCEL_PATH; return; }
    step();
  };
  const startCollect = async () => {
    if (!BRAND) return;
    if (!dStart.value || !dEnd.value || dStart.value > dEnd.value) { log('기간을 확인해 주세요.'); return; }
    await savePeriod();
    return startCollectWith({ start: dStart.value, end: dEnd.value, auto: false });
  };

  // ───────────── 구글 시트 ─────────────
  let prepared = null;
  let targetGid = '';             // 연결된(기재할) 시트 탭의 gid — 패널의 "연결" 버튼이나 설정에서 정한다
  let targetName = '';            // 연결된 탭 이름(화면 표시용)
  let nextRow = 0;                // 마지막으로 확인한, 연결된 탭의 다음 빈 행 번호
  const linkedLabel = () => (targetName ? `"${targetName}"` : (targetGid ? `gid ${targetGid}` : '(연결 안 됨)'));
  const activeTabName = () => { const e = document.querySelector('.docs-sheet-active-tab .docs-sheet-tab-name'); return e ? e.textContent.trim() : ''; };
  let lastCsv = null;             // 마지막으로 읽은 기재 탭의 CSV (날짜 묶음 계산용)
  const sheetGid = () => {
    // 시트는 탭을 바꿀 때 주소 끝(#gid=)만 바꾸는 경우가 있어 해시를 먼저 본다
    const m = /#gid=(\d+)/.exec(location.hash ? location.href : '') || /[?&]gid=(\d+)/.exec(location.href);
    return m ? m[1] : '0';
  };
  const sheetId = () => (/\/d\/([^/]+)/.exec(location.pathname) || [])[1];
  const bgFetch = url => new Promise(r => chrome.runtime.sendMessage({ type: 'fetchText', url }, r));

  const prepareRows = async () => {
    const res = await results();
    let all = []; T.BRANDS.forEach(b => { if (res[b.name]) all = all.concat(res[b.name].rows); });
    if (!all.length) { log('수집된 결과가 없습니다. 카페24에서 먼저 취합해 주세요.'); return null; }
    if (!targetGid) { log('연결된 시트 탭이 없습니다. 기재할 탭을 연 상태에서 "지금 열린 탭을 연결"을 눌러 주세요.'); return null; }
    let keys = null;
    const csv = await bgFetch(`https://docs.google.com/spreadsheets/d/${sheetId()}/export?format=csv&gid=${targetGid}`);
    lastCsv = csv && csv.ok ? csv.text : null;
    if (csv && csv.ok) {
      keys = T.existingKeys(csv.text);
      nextRow = T.nextEmptyRow(csv.text);
      log(`연결된 탭 ${linkedLabel()}의 다음 빈 행: ${nextRow}행`);
    } else log(`※ 연결된 탭 ${linkedLabel()}의 기존 주문번호를 읽지 못해 중복 제외를 못 했습니다. (` + ((csv && csv.error) || '응답 없음') + ')');
    const fresh = keys ? all.filter(r => !keys.has(r.brand + '|' + r.B)) : all;
    const sorted = T.sortRows(fresh);
    log(`전체 ${all.length}건 중 ${keys ? `이미 있는 ${all.length - fresh.length}건 제외, ` : ''}새로 넣을 ${sorted.length}건`);
    return sorted;
  };

  const pasteToSelected = (tsv, expected = nextRow) => {
    if (!targetGid || sheetGid() !== targetGid) { log(`연결된 탭 ${linkedLabel()}이 열려 있지 않습니다. 붙여넣지 않았습니다.`); return false; }
    // 선택된 칸이 A열이 아니면 모든 열이 한 칸씩 밀리므로 붙여넣지 않는다
    const nb = document.getElementById('t-name-box');
    const raw = nb ? String(nb.value || '').trim().toUpperCase() : '';
    // "A2" 같은 칸, "A2:C5" 같은 범위, "2:2"처럼 행 전체를 선택한 경우(그 행의 A열부터 붙는다)를 읽는다
    let m = /^([A-Z]+)(\d+)/.exec(raw);
    if (!m) { const r = /^(\d+):(\d+)$/.exec(raw); if (r) m = [r[0], 'A', r[1]]; }
    if (!m) { log(`선택된 칸 주소를 읽지 못해 붙여넣지 않았습니다. (읽은 값: "${raw || '없음'}") A열 칸을 한 번 클릭하고 다시 눌러 주세요.`); return false; }
    if (m[1] !== 'A') { log(`선택된 칸이 ${m[1]}${m[2]}입니다. A열 칸(예: A${nextRow || 2})을 선택한 뒤 다시 눌러 주세요. 붙여넣지 않았습니다.`); return false; }
    if (Number(m[2]) < 2) { log(`1행은 헤더입니다. A${Math.max(2, nextRow)}처럼 2행 이상의 칸을 선택해 주세요. 붙여넣지 않았습니다.`); return false; }
    if (expected && Number(m[2]) !== expected) { log(`선택된 칸이 A${m[2]}이고 넣을 위치는 A${expected}입니다. 붙여넣지 않았습니다.`); return false; }
    const el = document.querySelector('.cell-input');
    if (!el) { log('시트의 셀 입력 영역을 찾지 못했습니다.'); return false; }
    el.focus();
    const dt = new DataTransfer(); dt.setData('text/plain', tsv);
    el.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true }));
    // 붙여넣은 뒤 시트에 셀 편집 창이 남아 보이는 것을 닫는다
    setTimeout(() => el.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, which: 27, bubbles: true, cancelable: true })), 600);
    return true;
  };

  // 이름 상자에 주소를 넣고 Enter를 눌러 칸을 선택한다 (사용자 클릭 없이 A열 빈 행으로 이동)
  const selectCell = async addr => {
    const nb = document.getElementById('t-name-box');
    if (!nb) return false;
    nb.focus(); nb.select(); nb.value = addr;
    nb.dispatchEvent(new Event('input', { bubbles: true }));
    for (const t of ['keydown', 'keypress', 'keyup'])
      nb.dispatchEvent(new KeyboardEvent(t, { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true }));
    await sleep(700);
    return String(nb.value || '').trim().toUpperCase() === addr;
  };

  // 시트 메뉴 [삽입 → 행 → 위에 행 N개 삽입]을 눌러, firstRow부터 n개 행을 빈 행으로 끼워 넣는다
  const fireMouse = (el, types) => types.forEach(t => el.dispatchEvent(new MouseEvent(t, { bubbles: true, cancelable: true, view: window, button: 0 })));
  const visibleMenuItems = () => [...document.querySelectorAll('.goog-menuitem')].filter(e => e.offsetParent !== null);
  const insertRowsAbove = async (firstRow, n) => {
    if (!(await selectCell(`${firstRow}:${firstRow + n - 1}`))) throw new Error(`${firstRow}~${firstRow + n - 1}행 선택 실패`);
    const menu = document.getElementById('docs-insert-menu');
    if (!menu) throw new Error('시트의 삽입 메뉴를 찾지 못했습니다');
    fireMouse(menu, ['mousedown', 'mouseup', 'click']);
    await sleep(500);
    const rowItem = visibleMenuItems().find(e => /^행/.test((e.textContent || '').trim()));
    if (!rowItem) throw new Error('삽입 메뉴의 "행" 항목을 찾지 못했습니다');
    fireMouse(rowItem, ['mouseover', 'mousemove', 'mousedown', 'mouseup', 'click']);
    await sleep(600);
    const item = visibleMenuItems().find(e => /^위에 행/.test((e.textContent || '').trim()));
    if (!item) throw new Error('"위에 행 삽입" 항목을 찾지 못했습니다');
    fireMouse(item, ['mouseover', 'mousedown', 'mouseup', 'click']);
    await sleep(1200);
  };

  // 수집이 끝났을 때 자동으로: 새 건 확인 → 연결된 탭의 날짜 묶음 끝에 행 삽입 → 붙여넣기 (항상 2행 이상)
  let writing = false;
  const autoWrite = async () => {
    if (writing) return; writing = true;
    try {
      await store.set('tb_pending_write', 0);
      openPanel(true);
      log('자동 기재를 시작합니다…');
      const rows = await prepareRows();
      prepared = rows;
      await refreshActions();
      if (!rows || !rows.length) { log('새로 넣을 건이 없어 기재하지 않았습니다.'); return; }
      // 기재 탭의 날짜 묶음(A열 날짜)을 읽어, 각 날짜 묶음의 마지막 줄 아래에 행을 삽입해 넣는다
      if (!lastCsv) {
        const row = Math.max(2, nextRow || 2);
        if (!(await selectCell('A' + row))) { log(`A${row} 칸을 자동으로 선택하지 못했습니다.`); return; }
        if (pasteToSelected(T.toTsv(rows), row)) log(`${rows.length}건을 A${row}부터 기재했습니다. (날짜 묶음을 읽지 못해 맨 아래에 붙였습니다)`);
        await sleep(3000);
        return;
      }
      const { groups, last } = T.sheetGroups(T.parseCsv(lastCsv));
      const byDate = {};
      rows.forEach(r => { (byDate[r.A] = byDate[r.A] || []).push(r); });
      const counts = Object.keys(byDate).map(d => ({ date: T.normDate(d), key: d, count: byDate[d].length }));
      const plan = T.planInsertions(groups, last, counts);
      log(`날짜 ${plan.length}곳에 나눠 넣습니다: ` + plan.slice().reverse().map(o => `${o.date.slice(5)} ${o.count}건`).join(', '));
      let done = 0;
      for (const op of plan) {
        const bucket = byDate[counts.find(c => c.date === op.date).key];
        const first = op.after + 1;
        if (op.insert) await insertRowsAbove(first, op.count);
        if (!(await selectCell('A' + first))) { log(`A${first} 칸을 선택하지 못해 ${op.date} 건을 넣지 못했습니다.`); return; }
        if (!pasteToSelected(T.toTsvBucket(bucket, op.newGroup), first)) return;
        done += bucket.length;
        log(`${op.date}: ${bucket.length}건을 ${first}행${op.insert ? '(행 삽입)' : ''}에 넣었습니다.`);
        await sleep(1200);
      }
      log(`${done}건을 날짜별로 기재했습니다.`);
      await sleep(3000);   // 시트가 저장될 시간을 준다 (다음 브랜드의 중복 확인이 이 내용을 보도록)
    } catch (e) { log('자동 기재 실패: ' + e.message); }
    finally { writing = false; }
  };

  // ───────────── 동작 카드 ─────────────
  const actCard = $('act-card');
  const refreshActions = async () => {
    if (IS_SHEET) {
      if (!targetGid) {
        actCard.innerHTML = `
          <div class="card-title">시트에 넣기</div>
          <div class="note" style="margin-bottom:7.2px">기재할 시트 탭이 연결되어 있지 않습니다. 기재할 탭(예: 이번 주차 탭)을 연 상태에서 아래 버튼을 눌러 연결해 주세요.</div>
          <div class="row"><button class="btn-pri" id="a-link">지금 열린 탭을 연결 (${esc(activeTabName() || 'gid ' + sheetGid())})</button></div>`;
        $('a-link').addEventListener('click', () => linkCurrentTab());
        return;
      }
      if (sheetGid() !== targetGid) {
        actCard.innerHTML = `
          <div class="card-title">시트에 넣기</div>
          <div class="note" style="margin-bottom:7.2px">기재는 연결된 탭 ${esc(linkedLabel())}에 합니다. 지금은 다른 탭이 열려 있습니다.</div>
          <div class="row"><button class="btn-pri" id="a-goto">연결된 탭으로 이동</button></div>
          <div class="row"><button class="btn-sec" id="a-link">지금 열린 탭(${esc(activeTabName() || 'gid ' + sheetGid())})으로 연결 변경</button></div>`;
        $('a-goto').addEventListener('click', () => {
          location.href = `${location.origin}/spreadsheets/d/${sheetId()}/edit#gid=${targetGid}`;
        });
        $('a-link').addEventListener('click', () => linkCurrentTab());
        return;
      }
      actCard.innerHTML = `
        <div class="card-title">시트에 넣기 (연결된 탭 ${esc(linkedLabel())})</div>
        <div class="note" style="margin-bottom:7.2px">"붙여넣기"를 누르면 칸을 선택하지 않아도 연결된 탭의 해당 날짜 묶음 끝(2행 이상)에 행을 추가해 자동 기재합니다. 이미 있는 주문번호는 제외합니다.</div>
        <div class="row"><button class="btn-pri" id="a-paste">붙여넣기</button></div>
        <div class="row"><button class="btn-sec" id="a-prep">새 건 확인(미리보기)</button><button class="btn-sec" id="a-copy" disabled>표 복사</button></div>
        <details style="margin-top:7.2px"><summary class="note" style="cursor:pointer">붙여넣을 내용 미리보기</summary>
          <pre id="preview" class="note" style="white-space:pre-wrap;word-break:break-all;margin-top:5.4px;max-height:160px;overflow:auto"></pre></details>`;
      $('a-prep').addEventListener('click', async () => {
        prepared = await prepareRows();
        $('a-copy').disabled = !(prepared && prepared.length);
        $('preview').textContent = prepared ? T.toTsv(prepared).split('\n').map(l => l.split('\t').join(' | ')).join('\n') : '';
      });
      $('a-paste').addEventListener('click', () => autoWrite());
      $('a-copy').addEventListener('click', async () => {
        if (!prepared || !prepared.length) return;
        try { await navigator.clipboard.writeText(T.toTsv(prepared)); log('표를 클립보드에 복사했습니다.'); }
        catch (e) { log('복사 실패: ' + e.message); }
      });
    } else if (BRAND) {
      const res = await results();
      const done = res[BRAND];
      actCard.innerHTML = `
        <div class="card-title">${esc(BRAND)} 취합</div>
        <div class="note" style="margin-bottom:7.2px">이 브랜드로 로그인된 상태에서 눌러 주세요. 취소 관리 화면이 열렸다가 몇 번 새로고침됩니다.${done ? '<br>이미 수집한 결과는 덮어씁니다.' : ''}</div>
        <div class="row"><button class="btn-pri" id="a-go">${esc(BRAND)} 취합 시작</button></div>`;
      $('a-go').addEventListener('click', startCollect);
    } else {
      actCard.innerHTML = `<div class="card-title">취합</div><div class="note">이 주소는 등록된 브랜드가 아닙니다. 브랜드별 카페24 관리자 화면에서 열어 주세요.</div>`;
    }
  };

  // ───────────── 시작 ─────────────
  // 설정: 기재할 시트 탭 gid (시트 주소 끝의 gid=숫자)
  const setBody = $('set-body');
  setBody.innerHTML = `
    <div class="card-title">연결된 시트 탭</div>
    <div class="note" style="margin-bottom:5.4px">수집 결과는 여기에 연결된 탭에만 기재합니다.</div>
    <div class="note" id="s-linked" style="margin-bottom:7.2px;color:#0b5cab;font-weight:700"></div>
    <div class="row"><button class="btn-pri" id="s-gid-cur">지금 열린 시트 탭을 연결</button></div>
    <div class="note" style="margin:7.2px 0 5.4px">직접 입력하려면 시트 주소 끝의 gid 숫자를 넣고 저장하세요.</div>
    <div class="row"><input type="text" id="s-gid" inputmode="numeric"><button class="btn-sec" id="s-gid-save">저장</button></div>`;
  const showLinked = () => { $('s-linked').textContent = '연결된 탭: ' + linkedLabel() + (targetGid && targetName ? `  (gid ${targetGid})` : ''); };
  // 기재할 탭을 연결한다 (탭 번호와 이름을 저장)
  const setGid = async (v, name = '') => {
    targetGid = v; targetName = name;
    await store.set('tb_target_gid', v); await store.set('tb_target_name', name);
    $('s-gid').value = v; showLinked();
    log(`기재할 탭을 연결했습니다: ${linkedLabel()}`); refreshActions();
  };
  const linkCurrentTab = () => {
    if (!IS_SHEET) { log('구글 시트 화면에서 눌러 주세요.'); return; }
    return setGid(sheetGid(), activeTabName());
  };
  $('s-gid-cur').addEventListener('click', () => linkCurrentTab());
  $('s-gid-save').addEventListener('click', async () => {
    const v = $('s-gid').value.trim();
    if (!/^\d+$/.test(v)) { log('gid는 숫자만 입력해 주세요.'); return; }
    // 지금 열린 탭이 그 gid와 같으면 이름도 함께 저장한다
    await setGid(v, IS_SHEET && v === sheetGid() ? activeTabName() : '');
  });
  // 다른 탭(카페24)에서 수집 결과가 저장되면 이 화면의 브랜드 현황도 바로 갱신한다
  chrome.storage.onChanged.addListener((ch, area) => { if (area === 'local' && ch.tb_results) { renderBrands(); refreshActions(); } });
  // 시트 탭을 바꾸면 주소가 바뀌므로(이벤트 없이 바뀌는 경우도 있어) 주기적으로 확인해 화면을 갱신한다
  let lastGid = IS_SHEET ? sheetGid() : '';
  if (IS_SHEET) setInterval(async () => {
    const g = sheetGid();
    if (g !== lastGid) { lastGid = g; prepared = null; refreshActions(); }
    // 연결된 탭이 열려 있고 기재 요청이 와 있으면 자동으로 기재한다
    if (!writing && targetGid && g === targetGid && await store.get('tb_pending_write')) autoWrite();
  }, 2000);

  (async () => {
    targetGid = (await store.get('tb_target_gid')) || '';
    targetName = (await store.get('tb_target_name')) || '';
    // 연결된 탭이 지금 열려 있으면 이름을 최신으로 맞춘다 (탭 이름을 바꿨을 수 있음)
    if (IS_SHEET && targetGid && sheetGid() === targetGid && activeTabName() && activeTabName() !== targetName) { targetName = activeTabName(); store.set('tb_target_name', targetName); }
    $('s-gid').value = targetGid; showLinked();
    await loadPeriod();
    await renderBrands();
    await refreshActions();
    if (IS_SHEET) { store.set('tb_sheet', { id: sheetId() }); return; }   // 자동 기재를 위해 시트 주소를 기억해 둔다
    step();
    // 브랜드 "수집"을 눌러 로그인 화면을 연 경우: 로그인해서 그 브랜드 관리자 화면이 열리면 3~5초 뒤 자동으로 수집 시작
    const pend = await store.get('tb_pending');
    const isAdmin = /^\/(disp\/)?admin\//.test(location.pathname);
    if (BRAND && isAdmin && pend && pend.brand === BRAND && Date.now() - pend.ts < 30 * 60 * 1000 && !sessionStorage.getItem(JOB_KEY)) {
      await store.set('tb_pending', null);
      openPanel(true);
      const wait = 3000 + Math.floor(Math.random() * 2000);
      log(`${BRAND} 로그인 확인. ${Math.round(wait / 1000)}초 뒤 ${pend.start}~${pend.end} 수집을 시작합니다…`);
      await sleep(wait);
      startCollectWith({ start: pend.start, end: pend.end, auto: true });
    }
  })();
})();
