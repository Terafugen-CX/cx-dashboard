const LOGIN_URL = 'https://eclogin.cafe24.com/Shop/?url=Init&login_mode=2';

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  // 브랜드 "수집" 버튼: 카페24 로그인 화면을 새 탭으로 연다
  if (msg && msg.type === 'openLogin') {
    chrome.tabs.create({ url: LOGIN_URL, active: true });
    sendResponse({ ok: true });
    return;
  }

  // 수집이 끝났을 때: 시트 탭이 없으면 연결된 탭을 열고, 다른 탭이 열려 있으면 연결된 탭으로 바꿔 자동 기재가 이어지게 한다
  if (msg && msg.type === 'ensureSheet') {
    chrome.storage.local.get(['tb_sheet', 'tb_target_gid'], async ({ tb_sheet, tb_target_gid }) => {
      if (!tb_sheet || !tb_sheet.id) { sendResponse({ ok: false, error: '시트를 한 번도 열지 않았습니다' }); return; }
      if (!tb_target_gid) { sendResponse({ ok: false, error: '연결된 시트 탭이 없습니다 (시트 패널에서 "지금 열린 탭을 연결"을 눌러 주세요)' }); return; }
      const gid = tb_target_gid;
      const url = `https://docs.google.com/spreadsheets/d/${tb_sheet.id}/edit?gid=${gid}#gid=${gid}`;
      const tabs = await chrome.tabs.query({ url: `https://docs.google.com/spreadsheets/d/${tb_sheet.id}/*` });
      if (!tabs.length) { chrome.tabs.create({ url, active: false }); sendResponse({ ok: true, opened: true }); return; }
      const onTarget = tabs.some(t => (t.url || '').includes('gid=' + gid));
      if (!onTarget) chrome.tabs.update(tabs[0].id, { url });
      sendResponse({ ok: true, opened: false });
    });
    return true;
  }

  // 구글 시트의 CSV 내보내기를 대신 받아 준다 (콘텐츠 스크립트는 교차 출처 응답을 직접 못 받는다)
  if (!msg || msg.type !== 'fetchText') return;
  if (!/^https:\/\/docs\.google\.com\/spreadsheets\//.test(msg.url || '')) {
    sendResponse({ ok: false, error: '허용되지 않은 주소' });
    return;
  }
  fetch(msg.url, { credentials: 'include' })
    .then(r => (r.ok ? r.text() : Promise.reject(new Error('HTTP ' + r.status))))
    .then(text => sendResponse({ ok: true, text }))
    .catch(e => sendResponse({ ok: false, error: String(e && e.message || e) }));
  return true; // 비동기 응답
});
