﻿# 지금 PC에서 실행: git 에 없는 파일(동기화 서버, MD 문서)을 '가져갈파일' 폴더에 모은다.
# 끝나면 이 setup 폴더 통째로 USB·사내 드라이브로 새 PC에 옮긴다.
# 주의: sync-server\accounts.json 에 플랫폼 계정이 들어 있다. 메신저·메일로 보내지 말 것.
$ErrorActionPreference = 'Stop'
$carry = Join-Path $PSScriptRoot '가져갈파일'
$root = Join-Path $env:USERPROFILE 'Desktop\상담 자동화'
$syncDir = Join-Path $env:USERPROFILE 'Downloads\대시보드_백업\대시보드\sync-server'
if (Test-Path $carry) { Remove-Item $carry -Recurse -Force }
New-Item -ItemType Directory -Force $carry | Out-Null
robocopy $syncDir (Join-Path $carry 'sync-server') /E /XD node_modules /XF server.log /NFL /NDL /NJH /NJS | Out-Null
Write-Host "동기화 서버 복사: $syncDir"
Get-ChildItem $root -File | Where-Object { $_.Name -ne '인수인계.txt' } | Copy-Item -Destination $carry
if (Test-Path (Join-Path $root 'md파일')) { Copy-Item (Join-Path $root 'md파일') $carry -Recurse }
Write-Host 'MD 문서 복사 완료'
Write-Host ''
Write-Host "완료: $carry" -ForegroundColor Green
Write-Host '이 setup 폴더를 통째로 새 PC에 옮긴 뒤 2_새PC세팅.bat 을 실행하세요.'
Write-Host '(accounts.json 에 계정이 있으니 USB·사내 드라이브로만 옮기세요)' -ForegroundColor Yellow
