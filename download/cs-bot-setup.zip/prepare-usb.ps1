﻿# 지금 PC에서 실행: git 에 없는 플랫폼 계정 파일(accounts.json) 하나만 이 setup 폴더에 복사한다.
# 나머지(코드·MD 문서)는 새 PC에서 2_새PC세팅.bat 이 GitHub 에서 받는다.
# 주의: accounts.json 에 플랫폼 계정이 들어 있다. 메신저·메일로 보내지 말고 USB·사내 드라이브로만 옮길 것.
$ErrorActionPreference = 'Stop'
$src = Join-Path $env:USERPROFILE 'Downloads\대시보드_백업\대시보드\sync-server\accounts.json'
if (-not (Test-Path $src)) { Write-Host "계정 파일이 없습니다: $src" -ForegroundColor Yellow; exit 1 }
Copy-Item $src $PSScriptRoot -Force
Write-Host "완료: $(Join-Path $PSScriptRoot 'accounts.json')" -ForegroundColor Green
Write-Host '이 accounts.json 을 새 PC의 2_새PC세팅.bat 옆에 두고 실행하세요.'
Write-Host '(계정이 들어 있으니 USB·사내 드라이브로만 옮기세요)' -ForegroundColor Yellow
