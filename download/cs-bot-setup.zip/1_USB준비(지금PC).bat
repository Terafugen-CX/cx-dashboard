@echo off
rem Run on the current PC: collects files not in git into the carry folder
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0prepare-usb.ps1"
echo.
pause
