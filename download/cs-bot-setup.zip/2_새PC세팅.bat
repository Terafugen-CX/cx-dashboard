@echo off
rem Run on the new PC: installs and sets up everything
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup-pc.ps1"
echo.
pause
