@echo off
rem Run on the current PC: copies accounts.json (not in git) next to this file
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0prepare-usb.ps1"
echo.
pause
