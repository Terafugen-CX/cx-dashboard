﻿# 새 PC 원버튼 세팅: 프로그램 설치 → 저장소 받기 → 동기화 서버·로그 기록 자동 실행 → Cloudflare 로그인
# 2_새PC세팅.bat 이 실행한다. 같은 폴더의 '가져갈파일'(1_USB준비.bat 로 만든 것)이 있으면 함께 복사한다.
# 여러 번 실행해도 된다 (이미 있는 것은 건너뛰거나 최신으로 갱신).
$ErrorActionPreference = 'Continue'  # PS 5.1: 'Stop' 이면 git·npm 의 stderr 출력만으로 멈춤. 실패는 아래에서 직접 throw
$here = $PSScriptRoot
$carry = Join-Path $here '가져갈파일'
$root = Join-Path $env:USERPROFILE 'Desktop\상담 자동화'
$syncDir = Join-Path $env:USERPROFILE 'Downloads\대시보드_백업\대시보드\sync-server'
$startup = [Environment]::GetFolderPath('Startup')

function Step($msg) { Write-Host ''; Write-Host "== $msg" -ForegroundColor Cyan }
function RefreshPath { $env:Path = [Environment]::GetEnvironmentVariable('Path', 'Machine') + ';' + [Environment]::GetEnvironmentVariable('Path', 'User') }
function Need($cmd, $wingetId, $name) {
  if (Get-Command $cmd -ErrorAction SilentlyContinue) { Write-Host "$name 이미 설치됨"; return }
  Write-Host "$name 설치 중..."
  winget install --id $wingetId -e --accept-source-agreements --accept-package-agreements
  RefreshPath
  if (-not (Get-Command $cmd -ErrorAction SilentlyContinue)) { throw "$name 설치를 확인하지 못했습니다. 창을 닫고 2_새PC세팅.bat 을 다시 실행해 주세요." }
}

Step '1/7 프로그램 설치 (Node.js, Git, pm2)'
Need 'node' 'OpenJS.NodeJS.LTS' 'Node.js'
Need 'git' 'Git.Git' 'Git'
if (-not (Get-Command pm2 -ErrorAction SilentlyContinue)) { npm.cmd install -g pm2; RefreshPath } else { Write-Host 'pm2 이미 설치됨' }

Step '2/7 저장소 받기 (처음이면 GitHub 로그인 창이 뜹니다)'
New-Item -ItemType Directory -Force $root | Out-Null
foreach ($repo in 'cs-bot', 'cs-knowledge', 'cx-dashboard') {
  $dir = Join-Path $root $repo
  if (Test-Path (Join-Path $dir '.git')) { Write-Host "$repo 최신으로 갱신"; git -C $dir pull --ff-only }
  else { Write-Host "$repo 받는 중"; git clone "https://github.com/Terafugen-CX/$repo.git" $dir }
  if ($LASTEXITCODE) { throw "$repo 받기 실패" }
}
Push-Location (Join-Path $root 'cs-bot'); npm.cmd install; Pop-Location

Step '3/7 가져갈파일 복사 (동기화 서버, MD 문서)'
if (Test-Path $carry) {
  if (Test-Path (Join-Path $carry 'sync-server')) {
    robocopy (Join-Path $carry 'sync-server') $syncDir /E /XD node_modules /NFL /NDL /NJH /NJS | Out-Null
    Write-Host "동기화 서버 → $syncDir"
  }
  Get-ChildItem $carry -Exclude 'sync-server' | ForEach-Object { Copy-Item $_.FullName $root -Recurse -Force; Write-Host "$($_.Name) → $root" }
} else { Write-Host "'가져갈파일' 폴더가 없어 건너뜀 (동기화 서버·MD 문서는 직접 옮겨야 합니다)" -ForegroundColor Yellow }

Step '4/7 동기화 서버(3355) 설치·자동 실행'
if (Test-Path (Join-Path $syncDir 'server.js')) {
  Push-Location $syncDir; npm.cmd install; Pop-Location
  pm2 delete cx-server 2>$null | Out-Null
  pm2 start (Join-Path $syncDir 'server.js') --name cx-server --cwd $syncDir
  pm2 save
  # %APPDATA% 로 적어야 한글 사용자 이름이 깨지지 않는다 (ascii 로 쓰면 ??? 로 바뀜)
  Set-Content -Encoding ascii (Join-Path $startup 'cx-server.bat') "@echo off`r`n`"%APPDATA%\npm\pm2.cmd`" resurrect"
  Write-Host 'PC 켤 때 동기화 서버 자동 실행 등록'
} else { Write-Host '동기화 서버 폴더가 없어 건너뜀' -ForegroundColor Yellow }

Step '5/7 로그 기록 자동 실행 등록'
Copy-Item (Join-Path $root 'cs-bot\scripts\cs-bot-log.cmd') $startup -Force
$logPc = (Get-Content (Join-Path $root 'cs-bot\scripts\log-pc.txt') -TotalCount 1).Trim()
if ($logPc -eq $env:COMPUTERNAME) { Write-Host "이 PC($env:COMPUTERNAME)가 로그 기록 담당입니다" }
else { Write-Host "로그 기록 담당은 $logPc PC 입니다. 이 PC($env:COMPUTERNAME)에서는 기록하지 않습니다 (바꾸려면 cs-bot\scripts\log-pc.txt 수정 후 push)" -ForegroundColor Yellow }

Step '6/7 Cloudflare 로그인 (배포·로그·복구에 필요, 브라우저 창이 뜹니다)'
Push-Location (Join-Path $root 'cs-bot')
$who = npx.cmd wrangler whoami 2>&1 | Out-String
if ($who -match 'not authenticated|You are not') { npx.cmd wrangler login } else { Write-Host 'Cloudflare 이미 로그인됨' }
Pop-Location

Step '7/7 확인'
Start-Sleep 3
try { Invoke-RestMethod http://localhost:3355/ping | Out-Null; Write-Host '동기화 서버 정상 (localhost:3355)' -ForegroundColor Green }
catch { Write-Host '동기화 서버 응답 없음 - 가져갈파일\sync-server 가 있었는지 확인해 주세요' -ForegroundColor Yellow }
Write-Host ''
Write-Host '세팅 완료. 대시보드: https://terafugen-cx.github.io/cx-dashboard/' -ForegroundColor Green
