﻿# 새 PC 원버튼 세팅: 프로그램 설치 → 저장소 받기 → 동기화 서버·로그 기록 자동 실행 → Cloudflare 로그인
# 2_새PC세팅.bat 이 실행한다. 코드·MD 문서는 모두 GitHub 에서 받는다.
# 플랫폼 계정 파일(accounts.json)만 git 에 없다: 이 bat 옆에 두면 복사한다 (1_계정파일준비(지금PC).bat 로 만듦).
# 여러 번 실행해도 된다 (이미 있는 것은 건너뛰거나 최신으로 갱신).
$ErrorActionPreference = 'Continue'  # PS 5.1: 'Stop' 이면 git·npm 의 stderr 출력만으로 멈춤. 실패는 아래에서 직접 throw
$here = $PSScriptRoot
$root = Join-Path $env:USERPROFILE 'Desktop\상담 자동화'
$syncDir = Join-Path $env:USERPROFILE 'Downloads\대시보드_백업\대시보드\sync-server'
$startup = [Environment]::GetFolderPath('Startup')

function Step($msg) { Write-Host ''; Write-Host "== $msg" -ForegroundColor Cyan }
function RefreshPath { $env:Path = [Environment]::GetEnvironmentVariable('Path', 'Machine') + ';' + [Environment]::GetEnvironmentVariable('Path', 'User') }
function Need($cmd, $wingetId, $name) {
  if (Get-Command $cmd -ErrorAction SilentlyContinue) { Write-Host "$name 이미 설치됨"; return }
  Write-Host "$name 설치 중..."
  winget install --id $wingetId -e --accept-source-agreements --accept-package-agreements
  RefreshPath
  if (-not (Get-Command $cmd -ErrorAction SilentlyContinue)) { throw "$name 설치를 확인하지 못했습니다. 창을 닫고 2_새PC세팅.bat 을 다시 실행해 주세요." }
}
function Repo($name, $dir) {
  if (Test-Path (Join-Path $dir '.git')) { Write-Host "$name 최신으로 갱신"; git -C $dir pull --ff-only }
  else {
    # git 없이 복사해 둔 예전 폴더는 옆으로 치워 둔다 (계정 파일은 3단계에서 다시 가져옴)
    if (Test-Path $dir) { $bak = "$dir.bak-" + (Get-Date -Format 'yyyyMMdd-HHmmss'); Rename-Item $dir $bak; Write-Host "예전 폴더 보관: $bak" }
    New-Item -ItemType Directory -Force (Split-Path $dir) | Out-Null
    Write-Host "$name 받는 중"; git clone "https://github.com/Terafugen-CX/$name.git" $dir
  }
  if ($LASTEXITCODE) { throw "$name 받기 실패" }
}

Step '1/7 프로그램 설치 (Node.js, Git, pm2)'
Need 'node' 'OpenJS.NodeJS.LTS' 'Node.js'
Need 'git' 'Git.Git' 'Git'
if (-not (Get-Command pm2 -ErrorAction SilentlyContinue)) { npm.cmd install -g pm2; RefreshPath } else { Write-Host 'pm2 이미 설치됨' }

Step '2/7 저장소 받기 (처음이면 GitHub 로그인 창이 뜹니다)'
New-Item -ItemType Directory -Force $root | Out-Null
foreach ($repo in 'cs-bot', 'cs-knowledge', 'cx-dashboard') { Repo $repo (Join-Path $root $repo) }
Repo 'cx-sync-server' $syncDir
Push-Location (Join-Path $root 'cs-bot'); npm.cmd install; Pop-Location

Step '3/7 MD 문서·계정 파일'
$md = Join-Path $root 'md파일'
New-Item -ItemType Directory -Force $md | Out-Null
Copy-Item (Join-Path $root 'cs-bot\docs\md파일\*') $md -Force
Get-ChildItem (Join-Path $root 'cs-bot\docs') -File | Copy-Item -Destination $root -Force
Write-Host "MD 문서 → $root"
$acc = Join-Path $syncDir 'accounts.json'
$oldSync = Get-ChildItem (Split-Path $syncDir) -Directory -Filter 'sync-server.bak-*' -ErrorAction SilentlyContinue | Sort-Object Name | Select-Object -Last 1
$from = @((Join-Path $here 'accounts.json'))
if ($oldSync) { $from += (Join-Path $oldSync.FullName 'accounts.json') }
$accFrom = $from | Where-Object { Test-Path $_ } | Select-Object -First 1
if ($accFrom) { Copy-Item $accFrom $acc -Force; Write-Host '플랫폼 계정 파일 복사 완료' }
elseif (Test-Path $acc) { Write-Host '플랫폼 계정 파일 이미 있음' }
else { Write-Host '플랫폼 계정 파일(accounts.json)이 없습니다. AI 상담봇은 없어도 작동합니다. 재고·적립금 기능이 필요하면 지금 PC에서 1_계정파일준비(지금PC).bat 을 실행해 만든 accounts.json 을 이 bat 옆에 두고 다시 실행하세요' -ForegroundColor Yellow }

Step '4/7 동기화 서버(3355) 설치·자동 실행'
Push-Location $syncDir; npm.cmd install; Pop-Location
pm2 delete cx-server 2>$null | Out-Null
pm2 start (Join-Path $syncDir 'server.js') --name cx-server --cwd $syncDir
pm2 save
# %APPDATA% 로 적어야 한글 사용자 이름이 깨지지 않는다 (ascii 로 쓰면 ??? 로 바뀜)
Set-Content -Encoding ascii (Join-Path $startup 'cx-server.bat') "@echo off`r`n`"%APPDATA%\npm\pm2.cmd`" resurrect"
Write-Host 'PC 켤 때 동기화 서버 자동 실행 등록'

Step '5/7 로그 기록 자동 실행 등록'
Copy-Item (Join-Path $root 'cs-bot\scripts\cs-bot-log.cmd') $startup -Force
$logPc = (Get-Content (Join-Path $root 'cs-bot\scripts\log-pc.txt') -TotalCount 1).Trim()
if ($logPc -eq $env:COMPUTERNAME) { Write-Host "이 PC($env:COMPUTERNAME)가 로그 기록 담당입니다" }
else { Write-Host "로그 기록 담당은 $logPc PC 입니다. 이 PC($env:COMPUTERNAME)에서는 기록하지 않습니다 (바꾸려면 cs-bot\scripts\log-pc.txt 수정 후 push)" -ForegroundColor Yellow }

Step '6/7 Cloudflare 로그인 (배포·로그·복구에 필요, 브라우저 창이 뜹니다)'
Push-Location (Join-Path $root 'cs-bot')
$who = npx.cmd wrangler whoami 2>&1 | Out-String
if ($who -match 'not authenticated|You are not') { npx.cmd wrangler login } else { Write-Host 'Cloudflare 이미 로그인됨' }
Pop-Location

Step '7/7 확인'
Start-Sleep 3
try { Invoke-RestMethod http://localhost:3355/ping | Out-Null; Write-Host '동기화 서버 정상 (localhost:3355)' -ForegroundColor Green }
catch { Write-Host '동기화 서버 응답 없음 - pm2 logs cx-server 로 오류를 확인해 주세요' -ForegroundColor Yellow }
Write-Host ''
Write-Host '세팅 완료. 대시보드: https://terafugen-cx.github.io/cx-dashboard/' -ForegroundColor Green
